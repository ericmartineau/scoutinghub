package org.grails.plugins.geolocation


import org.grails.plugins.geolocation.Coordinates;

class GeoPosition {
	Coordinates coords
	long timestamp
    static constraints = {
    }
}
