/**
* Gant script that copy iwebkit scaffolding templates to the project src/remplate folder
*
* @author Sebastien Blanc
*
*
*/

includeTargets << grailsScript("_GrailsInit")

target ('default': "Installs the iwebkit scaffolding templates") {
    depends(checkVersion, parseArguments)

    targetDir = "${basedir}/src/templates/scaffolding"
    overwrite = false

    // only if template dir already exists in, ask to overwrite templates
    if (new File(targetDir).exists()) {
        if (!isInteractive || confirmInput("Overwrite existing templates? [y/n]","overwrite.templates"))
            overwrite = true
    }
    else {
        ant.mkdir(dir: targetDir)
    }


    ant.copy(todir: targetDir, overwrite: overwrite) {

        fileset(dir: "${iwebkitPluginDir}/src/templates", includes: "*")
    }

    event("StatusUpdate", [ "iwebkit Templates installed successfully"])
}



