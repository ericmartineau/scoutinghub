package webkit
class IphoneTagLib {
static namespace = "iwebkit"

def list = {attrs, body ->
  if(attrs.imageField){
		out << render(template:"${pluginContextPath}/grails-app/views/templates/imageList",model:[attrs:attrs])
	}
	else{
		out << render(template:"${pluginContextPath}/grails-app/views/templates/simpleList",model:[attrs:attrs])
	}
}

def topbar = {attrs, body ->
out << render(template:"${pluginContextPath}/grails-app/views/templates/topbar",model:[attrs:attrs, body:body])
}

def title = {attrs, body ->
out << render(template:"${pluginContextPath}/grails-app/views/templates/title",model:[attrs:attrs, body:body])
}

def leftnavigation = {attrs, body ->
	def type
	if(attrs.navtype=="arrow")
		type = "leftnav"
	if(attrs.navtype=="button")
		type = "leftbutton"

out << render(template:"${pluginContextPath}/grails-app/views/templates/navigation",model:[attrs:attrs, body:body, type:type])
}

def rightnavigation = {attrs, body ->
	def type
	if(attrs.navtype=="arrow")
		type = "rightnav"
	if(attrs.navtype=="button")
		type = "rightbutton"
out << render(template:"${pluginContextPath}/grails-app/views/templates/navigation",model:[attrs:attrs, body:body,type:type])
}

def navelement = {attrs, body ->
out << render(template:"${pluginContextPath}/grails-app/views/templates/navelement",model:[attrs:attrs, body:body])
}

def content = {attrs, body ->
out << render(template:"${pluginContextPath}/grails-app/views/templates/content",model:[attrs:attrs, body:body])
}

def section = {attrs, body ->
out << render(template:"${pluginContextPath}/grails-app/views/templates/section",model:[attrs:attrs, body:body])
}

def textbox = {attrs, body ->
out << render(template:"${pluginContextPath}/grails-app/views/templates/textbox",model:[attrs:attrs, body:body])
}

def locateMe =  {attrs, body ->
  out << render(template:"${pluginContextPath}/grails-app/views/templates/geolocation",model:[attrs:attrs, body:body])

}

def angle =  {attrs, body ->
out << render(template:"${pluginContextPath}/grails-app/views/templates/angle",model:[attrs:attrs, body:body])
}

def textField =  {attrs, body ->
out << render(template:"${pluginContextPath}/grails-app/views/templates/textfield",model:[attrs:attrs, body:body])
}

def textarea =  {attrs, body ->
out << render(template:"${pluginContextPath}/grails-app/views/templates/textarea",model:[attrs:attrs, body:body])
}

def password =  {attrs, body ->
out << render(template:"${pluginContextPath}/grails-app/views/templates/passwordField",model:[attrs:attrs, body:body])
}

def checkbox =  {attrs, body ->
out << render(template:"${pluginContextPath}/grails-app/views/templates/checkbox",model:[attrs:attrs, body:body])
}

def submit =  {attrs, body ->
out << render(template:"${pluginContextPath}/grails-app/views/templates/submit",model:[attrs:attrs, body:body])
}
}